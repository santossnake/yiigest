groupgridview
=============

Yii extension to group data in your grid

Please see **[demo](http://groupgridview.demopage.ru)** for details